class Chair extends Seat {

	public Chair(double w, int cap) {

		super(w, cap);
	}

	public int getCapacity() {

		return 1;
	}
}