class Furniture {

	protected double weight;

	public Furniture(double w) {

		weight = w;
	}

	public double getWeight() {

		return weight;
	}

	public void setWeight(double w) {

		weight = w;
	}
}